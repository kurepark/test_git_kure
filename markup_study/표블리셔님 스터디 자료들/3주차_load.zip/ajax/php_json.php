<!DOCTYPE html>
<html lang="ko">
<head>
	<meta charset="utf-8" />
	<meta http-equiv="X-UA-Compatible" content="IE=edge" />
	<meta name="viewport" content="width=device-width,initial-scale=1.0,minimum-scale=1.0,maximum-scale=2.0,user-scalable=yes" />
	<title>pyo</title>
	<script src="https://code.jquery.com/jquery-3.1.1.min.js" type="text/javascript"></script>
	<script type="text/javascript">
	//<![CDATA[
		$(document).ready(function(){
			$.ajax({
				type: 'GET',
				url: 'php_json_data.php',
				dataType: 'json',
				data: ''
			}).done(function(data) {
				for(var i=0; i<data.length; i++){
					var num1 = data[i].num1,
						num2 = data[i].num2,
						num3 = data[i].num3;
					$('.box').append('<div>num1 : '+num1+' / num2 : '+num2+' / num3 : '+num3+'</div>');
				}
			}).fail(function() {
				alert('error');
			}).always(function() {
				//alert('어쩌라구');
			});
		});
	//]]>
	</script>
</head>
<body>

<div class="box"></div>

</body>
</html>
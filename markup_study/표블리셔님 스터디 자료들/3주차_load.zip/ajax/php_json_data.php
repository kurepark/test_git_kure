<?php

header('Content-Type: application/json');

$data = '';
for($i=0;$i<10;$i++){
	$data .= '{"num1" : "'.$i.'", "num2" : "'.($i+2).'", "num3" : "'.($i*2).'"}';
	if($i!=9) $data .= ',';
}

die('['.$data.']');




//die('[
//	{
//		"num1" : "1",
//		"num2" : "표정민",
//		"num3" : "퍼블리셔"
//	},
//	{
//		"num1" : "2",
//		"num2" : "홍길동",
//		"num3" : "도둑"
//	},
//	{
//		"num1" : "3",
//		"num2" : "임꺽정",
//		"num3" : "산적"
//	}
//]');